num = 10 + 20;
num = 11.50/2;
myRemainder = 20 % 8;
console.log(myRemainder);
string = 'Hello' + ' World';
favoriteFood = 'Pizza';
favoriteFood = 'Tacos';