contacts = ['Matt Smith', 'Sam Davis', 'Ashley Jones'];
secondContact = contacts[1];
console.log('The second contact in your book is '+ secondContact);
contacts.push('Frank Smith');
contacts.pop();
contacts[0] = 'Phillip Sanders';
contacts[contacts.length-1] = 'Bill Sanders';