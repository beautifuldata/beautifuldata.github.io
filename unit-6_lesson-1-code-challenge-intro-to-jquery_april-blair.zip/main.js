//Introducing jQuery
$(function() {
     console.log("Hello world");
  
  // Select element by id
  $("#thumbnails");
  
  // Select element by class
  $('.thumbnail');
  
  //Select all ul elements
  $('ul');
  
  //Select element with a nested selector
  $('ul li');
});