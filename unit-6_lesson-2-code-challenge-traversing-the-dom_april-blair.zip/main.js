$(function() {
//Student Code Start
  // Step 1
  $('#thumbnails').children('div');
  
  // Step 2
  $('#thumbnails').children('div').children('img');
  
  // Step 3
  $('#thumbnails').find('.thumbnail');
  
  // Step 4
  $('#thumbnails').children();
  
  // Step 5
  $('.thumbnail').parent().parent('#thumbnails');
  
  // Step 6
  $('.thumbnail').parent('div').next().children('.thumbnail');
  
  // Step 7
  $('#thumbnails div:last-child').prev().children('.thumbnail');

});