$('button').on('click', function () {

	// Add your code here!

	// Step 1: Add the party class to the .square


	// Step 2: Use the .attr() method to update the src of the image to 'images/cat.jpeg'


	// Step 3: Change the HTML for the h1 to "Having fun!" using the .html() method.


	// Step 4: Prepend the following paragraph to the body element:
	//    '<p>Done and Done!</p>'


});